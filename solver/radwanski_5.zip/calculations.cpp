//
// Created by valleron on 5/5/26.
//

#include <cmath>
#include <iomanip>
#include <ios>
#include <iostream>
#include <ostream>

long double given_function(const long double x) {
    return x * 0.00050105102370736977L - 30 * expl(-11 * x) + 0.03333333333333333333L;
}

long double given_differential(const long double x) {
    return 0.00050105102370736977L + 330 * expl(-11 * x);
}

/*
 *@param start - punkt startowy dla metody Newtona
 *@param max_iterations - maksymalna liczba iteracji, po której metoda się zakończy niezależnie od warunku stopu
 *@param stop_fx - jeśli true stosowane jest kryterium resydualne, w przeciwnym razie stosowane jest kryterium bliskości argumentóœ
 *@param rho - wartość rho dla której kryterium jest uznane za spełnione
 *@param out_of_bounds - flaga jest ustawiana przez funkcję na true jeżeli w trakcie szukania miejsca zerowego funkcja wychodzi poza zakres [0,2]
 *@param total_iterations - zmienna jest ustawiana na liczbę iteracji wykonanych przez metodę
 *@return - wyznaczone miejsce zerowe
 */
long double newton_method(long double start, const int max_iterations, const bool stop_fx, const long double rho, bool& out_of_bounds, int& total_iterations) {
    out_of_bounds = false;
    total_iterations = 0;
    for (int i=0;i<max_iterations;i++) {
        const long double last = start;
        start -=    given_function(start) / given_differential(start);
        out_of_bounds = out_of_bounds  || start < 0 || start > 2;

        if ((stop_fx && fabsl(given_function(start)) < rho) ||
            (!stop_fx && fabsl(start - last) < rho)) {
            total_iterations = i+1;
            return start;
            }

    }
    total_iterations=max_iterations;
    return start;
}


/*@param a - x_1 warunek początkowy
*@param max_iterations - maksymalna liczba iteracji, po której metoda się zakończy niezależnie od warunku stopu
 *@param stop_fx - jeśli true stosowane jest kryterium resydualne, w przeciwnym razie stosowane jest kryterium bliskości argumentóœ
 *@param rho - wartość rho dla której kryterium jest uznane za spełnione
 *@param out_of_bounds - flaga jest ustawiana przez funkcję na true jeżeli w trakcie szukania miejsca zerowego funkcja wychodzi poza zakres [0,2]
 *@param total_iterations - zmienna jest ustawiana na liczbę iteracji wykonanych przez metodę
 *@param division_by_zero - flaga jest ustawiana na true jeżeli metoda zakończyła działanie przedwcześnie ze względu na dzielenie przez 0
 *@return - wyznaczone miejsce zerowe
 */
long double secant_method(long double a, long double b, const int max_iterations, const bool stop_fx, const long double rho, bool& out_of_bounds, int& total_iterations, bool& division_by_zero) {
    out_of_bounds = false;
    division_by_zero = false;
    long double current=0;
    long double fa = given_function(a);
    for (int i=0;i<max_iterations; i++) {
        out_of_bounds = out_of_bounds  || current < 0 || current > 2;
        if (fabsl(fa - given_function(b)) <1e-18) {
            total_iterations = i;
            division_by_zero = true;
            return current;
        }
        current = a - ((a - b)/(fa - given_function(b))) * fa;

        fa = given_function(current);
        if ((stop_fx && fabsl(fa) < rho) ||
            (!stop_fx && fabsl(current - a) < rho) && i>1) {
            total_iterations = i+1;
            return current;
            }
        b = a;
        a = current;
    }
    total_iterations = max_iterations;
    return current;

}
