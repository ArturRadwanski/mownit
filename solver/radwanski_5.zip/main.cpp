#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <ios>
#include "calculations.h"
constexpr long double real_x = 0.61755951994795290169;

void check_newton(std::ofstream& file, const bool stop_fx, const std::string& table_title) {
    file << "\\begin{table}[H]\n\\centering\n\\footnotesize\n";
    file << "\\begin{tabular}{|l|" << "|c|c|c|c|c|c|c|c|c|" << "}\n\\toprule\n";
    file << "$x_0$";
    for (int j = 1; j < 10; j++) file << " & $\\rho=10^{-" << 2*j << "}$";
    file << " \\\\\n\\midrule \\midrule\n";

    for (int i = 0; i <= 20; i++) {
        long double start = 0.1L * i;
        file << std::fixed << std::setprecision(1) << start;

        for (int j = 1; j < 10; j++) {
            const long double rho = std::pow(0.01L, j);
            bool out_of_bounds = false;
            int total_iterations = 0;
            const long double x = newton_method(start, 1e4, stop_fx, rho, out_of_bounds, total_iterations);
            const long double err = std::fabsl(x - real_x);

            file << " & \\makecell{";
            if (out_of_bounds) file << "\\ul{";
            file << std::scientific << std::setprecision(2) << err;
            if (out_of_bounds) file << "}";
            file << " \\\\ " << total_iterations << "}";
        }
        std::cout << 5*i <<"%\n";
        file << " \\\\\n\\hline\n ";
    }
    file << "\\bottomrule\n\\end{tabular}";
    file << "\\caption{" << table_title << "}\n\\end{table}";
}

void check_secant(std::ofstream& file, std::ofstream& fileB, const bool stop_fx, const std::string& table_title) {
    file << "\\begin{table}[H]\n\\centering\n\\footnotesize\n";
    file << "\\begin{tabular}{|l|" << "|c|c|c|c|c|c|c|c|c|" << "}\n\\toprule\n";
    file << "$x_1$";
    for (int j = 1; j < 10; j++) file << " & $\\rho=10^{-" << 2*j << "}$";
    file << " \\\\\n\\midrule \\midrule\n";

    for (int i = 0; i < 20; i++) {
        long double start = 0.1 * i;
        file << std::fixed << std::setprecision(1) << start;

        for (int j = 1; j < 10; j++) {
            const long double rho = std::pow(0.01L, j);
            bool out_of_bounds = false, division_by_Zero=false;
            int total_iterations = 0;
            const long double x = secant_method(start, 2.0, 1e4, stop_fx, rho, out_of_bounds, total_iterations, division_by_Zero);
            const long double err = std::fabsl(x - real_x);

            file << " & \\makecell{";
            if (out_of_bounds) file << "\\ul{";
            file << std::scientific << std::setprecision(2) << err;
            if (out_of_bounds) file << "}";
            file << " \\\\ ";
            if (division_by_Zero) file << "\\textcolor{Green}{" << total_iterations << "}}";
            else file << total_iterations << "}";
        }
        std::cout << 5*i <<"%\n";
        file << " \\\\\n\\hline\n ";
    }
    file << "\\bottomrule\n\\end{tabular}";
    file << "\\caption{" << table_title << "}\n\\end{table}";

    fileB << "\\begin{table}[H]\n\\centering\n\\footnotesize\n";
    fileB << "\\begin{tabular}{|l|" << "|c|c|c|c|c|c|c|c|c|" << "}\n\\toprule\n";
    fileB << "$x_0$";
    for (int j = 1; j < 10; j++) fileB << " & $\\rho=10^{-" << 2*j << "}$";
    fileB << " \\\\\n\\midrule \\midrule\n";

    for (int i = 0; i < 20; i++) {
        long double start = 2 - 0.1 * i;
        fileB << std::fixed << std::setprecision(1) << start;

        for (int j = 1; j < 10; j++) {
            const long double rho = std::pow(0.01L, j);
            bool out_of_bounds = false, division_by_zero = false;
            int total_iterations = 0;
            const long double x = secant_method(0.0, start, 1e4, stop_fx, rho, out_of_bounds, total_iterations, division_by_zero);
            const long double err = std::fabsl(x - real_x);

            fileB << " & \\makecell{";
            if (out_of_bounds) fileB << "\\ul{";
            fileB << std::scientific << std::setprecision(2) << err;
            if (out_of_bounds) fileB << "}";
            fileB << " \\\\ ";
            if (division_by_zero) fileB << "\\textcolor{Green}{" << total_iterations << "}}";
            else fileB << total_iterations << "}";

        }
        std::cout << 5*i <<"%\n";
        fileB << " \\\\\n\\hline\n ";
    }
    fileB << "\\bottomrule\n\\end{tabular}";
    fileB << "\\caption{" << table_title << "}\n\\end{table}";
}

int main() {
    std::ofstream file("tabela_wynikow_fx.tex");
    std::ofstream file2("tabela_wynikow_x.tex");
    check_newton(file, true, "uwu");
    check_newton(file2, false, "uwu");
    file.close();
    file2.close();
    // bool out_of_bounds = false, division_by_zero = false;
    // int iterations;
    // long double x = secant_method(0.5, 2.0, 1e2, true, 1e-18, out_of_bounds, iterations, division_by_zero);
    // std::cout << fabsl(x - real_x) << "    " << iterations << "\n";
    // std::cout << 1e4;
    return 0;
}